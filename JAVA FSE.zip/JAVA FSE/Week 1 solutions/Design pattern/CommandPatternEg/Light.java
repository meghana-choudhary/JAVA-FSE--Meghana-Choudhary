public class Light 
{
    public void lighton() 
    {
        System.out.println("Light's on");
    }
    public void lightoff() 
    {
        System.out.println("Light's off");
    }
}