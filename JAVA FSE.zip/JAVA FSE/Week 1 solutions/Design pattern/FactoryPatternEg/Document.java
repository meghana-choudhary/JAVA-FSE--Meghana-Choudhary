public interface Document
{
    public void open();
    public void manage();
    public void save();
}