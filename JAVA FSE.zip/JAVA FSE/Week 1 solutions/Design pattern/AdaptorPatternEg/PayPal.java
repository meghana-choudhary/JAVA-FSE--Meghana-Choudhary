public class PayPal {
    public void p2(double amt) {
        System.out.println("Payment is processing " + amt + " through PayPal");
    }
}
